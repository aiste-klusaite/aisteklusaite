<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="zmones.css">
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Raleway|Source+Sans+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
</head>

<body>
    <div class="container">
    <div class="header-container">
        <div class="title"><h1>MONIKA MOZŪRAITĖ</h1></div>
     <div id="burger" class="burger" onclick="navSlide()"> 
         <div class="line1"></div>
         <div class="line2"></div>
         <div class="line3"></div>
        </div>
        <div class="nav-bar"> <!--linkai į page'us-->
            <ul class="nav-links">
                <li><a class="link" href="../header/pradinis.php" target="_self">Pradžia</a></li> <!--cia bus linkas i pradini psl-->
                <li><a class="link" href="../apie/Apie.php" target="_self">Apie</a></li> 
                <li><a class="link" href="../Nuotraukos/Nuotraukos.php" target="_self">Nuotraukos</a></li>
                <li><a class="link" href="../kontaktai/kontaktai.php" target="_self">Kontaktai</a></li>
            </ul>
        </div>
        <div class="soc-bar">
            <ul class="soc-links">
                <li><a href="https://www.facebook.com/monikaphotography1/"><i class="fab fa-facebook-square"></i></a></li>
                <li><a href="https://www.instagram.com/mozu_reikalai/"><i class="fab fa-instagram"></i></a></li>
                <li><a href="mailto:mozurai1@gmail.com"><i class="fas fa-envelope"></i></a></li>
                <li><a href="tel:+37060062915"><i class="fas fa-mobile-alt"></i></a></li>
            </ul>
        </div> 
    </div>
   <div class="foto_row">
       <div class="foto_column">
            <div><a href="portretai/zmones1.jpg" data-fancybox="gallery"><img src="portretai/zmones1.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones4.jpg" data-fancybox="gallery"><img src="portretai/zmones4.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones23.jpg" data-fancybox="gallery"><img src="portretai/zmones23.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones16.jpg" data-fancybox="gallery"><img src="portretai/zmones16.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones11.jpg" data-fancybox="gallery"><img src="portretai/zmones11.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones21.jpg" data-fancybox="gallery"><img src="portretai/zmones21.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones28.jpg" data-fancybox="gallery"><img src="portretai/zmones28.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones13.jpg" data-fancybox="gallery"><img src="portretai/zmones13.jpg" width="100%"></a></div>
       </div>
       <div class="foto_column">
           <div><a href="portretai/zmones19.jpg" data-fancybox="gallery"><img src="portretai/zmones19.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones2.jpg" data-fancybox="gallery"><img src="portretai/zmones2.jpg" width="100%"></a></div>
           <div><a href="portretai/zmones30.jpg" data-fancybox="gallery"><img src="portretai/zmones30.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones9.jpg" data-fancybox="gallery"><img src="portretai/zmones9.jpg" width="100%"></a></div>
             <div><a href="portretai/zmones34.jpg" data-fancybox="gallery"><img src="portretai/zmones34.jpg" width="100%"></a></div> 
            <div><a href="portretai/zmones29.jpg" data-fancybox="gallery"><img src="portretai/zmones29.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones37.jpg" data-fancybox="gallery"><img src="portretai/zmones37.jpg" width="100%"></a></div>
       </div>
       <div class="foto_column">
           <div><a href="portretai/zmones10.jpg" data-fancybox="gallery"><img src="portretai/zmones10.jpg" width="100%"></a></div>
           <div><a href="portretai/zmones17.jpg" data-fancybox="gallery"><img src="portretai/zmones17.jpg" width="100%"></a></div>
           <div><a href="portretai/zmones18.jpg" data-fancybox="gallery"><img src="portretai/zmones18.jpg" width="100%"></a></div>
           <div><a href="portretai/zmones12.jpg" data-fancybox="gallery"><img src="portretai/zmones12.jpg" width="100%"></a></div>
           <div><a href="portretai/zmones27.jpg" data-fancybox="gallery"><img src="portretai/zmones27.jpg" width="100%"></a></div>
           <div><a href="portretai/zmones36.jpg" data-fancybox="gallery"><img src="portretai/zmones36.jpg" width="100%"></a></div>
           <div><a href="portretai/zmones33.jpg" data-fancybox="gallery"><img src="portretai/zmones33.jpg" width="100%"></a></div>
           <div><a href="portretai/zmones25.jpg" data-fancybox="gallery"><img src="portretai/zmones25.jpg" width="100%"></a></div>
       </div>
        <div class="foto_column">
            <div><a href="portretai/zmones32.jpg" data-fancybox="gallery"><img src="portretai/zmones32.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones24.jpg" data-fancybox="gallery"><img src="portretai/zmones24.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones7.jpg" data-fancybox="gallery"><img src="portretai/zmones7.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones20.jpg" data-fancybox="gallery"><img src="portretai/zmones20.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones26.jpg" data-fancybox="gallery"><img src="portretai/zmones26.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones22.jpg" data-fancybox="gallery"><img src="portretai/zmones22.jpg" width="100%"></a></div>
            <div><a href="portretai/zmones15.jpg" data-fancybox="gallery"><img src="portretai/zmones15.jpg" width="100%"></a></div>
       </div>       
        </div>
    
    <footer>
        <h4>MONIKA MOZŪRAITĖ</h4>
        <p>COPYRIGHT 2020</p>
    </footer>
</div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    <script src="zmones.js"></script><script src="../header/header.js"></script>
</body>
</html>