<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="gamta.css">
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Raleway|Source+Sans+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
</head>

<body>
    <div class="container">
        <heder>
    <div class="header-container">
        <div class="title"><h1>MONIKA MOZŪRAITĖ</h1></div>
     <div id="burger" class="burger" onclick="navSlide()"> 
         <div class="line1"></div>
         <div class="line2"></div>
         <div class="line3"></div>
        </div>
        <div class="nav-bar"> <!--linkai į page'us-->
            <ul class="nav-links">
                <li><a class="link" href="../header/pradinis.php" target="_self">Pradžia</a></li> <!--cia bus linkas i pradini psl-->
                <li><a class="link" href="../apie/Apie.php" target="_self">Apie</a></li> 
                <li><a class="link" href="../Nuotraukos/Nuotraukos.php" target="_self">Nuotraukos</a></li>
                <li><a class="link" href="../kontaktai/kontaktai.php" target="_self">Kontaktai</a></li>
            </ul>
        </div>
        <div class="soc-bar">
            <ul class="soc-links">
                <li><a href="https://www.facebook.com/monikaphotography1/"><i class="fab fa-facebook-square"></i></a></li>
                <li><a href="https://www.instagram.com/mozu_reikalai/"><i class="fab fa-instagram"></i></a></li>
                <li><a href="mailto:mozurai1@gmail.com"><i class="fas fa-envelope"></i></a></li>
                <li><a href="tel:+37060062915"><i class="fas fa-mobile-alt"></i></a></li>
            </ul>
        </div> 
    </div>
    </heder>
   <div class="foto_row">
       <div class="foto_column">
            <div><a href="gamta/gamta1.JPG" data-fancybox="gallery"><img src="gamta/gamta1.JPG" width="100%"></a></div>
           <div><a href="gamta/gamta2.JPG" data-fancybox="gallery"><img src="gamta/gamta2.jpg" width="100%"></a></div>
            <div><a href="gamta/gamta9.JPG" data-fancybox="gallery"><img src="gamta/gamta9.JPG" width="100%"></a></div>
            <div><a href="gamta/gamta22.JPG" data-fancybox="gallery"><img src="gamta/gamta22.JPG" width="100%"></a></div>
       </div>
       <div class="foto_column"> 
            <div><a href="gamta/gamta8.JPG" data-fancybox="gallery"><img src="gamta/gamta8.JPG" width="100%"></a></div>
            <div><a href="gamta/gamta4.JPG" data-fancybox="gallery"><img src="gamta/gamta4.JPG" width="100%"></a></div>
            <div><a href="gamta/gamta19.JPG" data-fancybox="gallery"><img src="gamta/gamta19.JPG" width="100%"></a></div>
            <div><a href="gamta/gamta16.JPG" data-fancybox="gallery"><img src="gamta/gamta16.JPG" width="100%"></a></div>
       </div>
       <div class="foto_column">
            <div><a href="gamta/gamta5.JPG" data-fancybox="gallery"><img src="gamta/gamta5.JPG" width="100%"></a></div>
            <div><a href="gamta/gamta6.JPG" data-fancybox="gallery"><img src="gamta/gamta6.JPG" width="100%"></a></div>
            <div><a href="gamta/gamta21.JPG" data-fancybox="gallery"><img src="gamta/gamta21.JPG" width="100%"></a></div>
            <div><a href="gamta/gamta17.JPG" data-fancybox="gallery"><img src="gamta/gamta17.JPG" width="100%"></a></div>
       </div>
       <div class="foto_column">
            <div><a href="gamta/gamta10.JPG" data-fancybox="gallery"><img src="gamta/gamta10.JPG" width="100%"></a></div>
             <div><a href="gamta/gamta7.JPG" data-fancybox="gallery"><img src="gamta/gamta7.JPG" width="100%"></a></div>
           <div><a href="gamta/gamta15.JPG" data-fancybox="gallery"><img src="gamta/gamta15.JPG" width="100%"></a></div>
           <div><a href="gamta/gamta24.JPG" data-fancybox="gallery"><img src="gamta/gamta24.JPG" width="100%"></a></div>
       </div>
        </div>
        
    <footer>
        <h4>MONIKA MOZŪRAITĖ</h4>
        <p>COPYRIGHT 2020</p>
    </footer>
</div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    <script src="gamta.js"></script> <script src="../header/header.js"></script>
</body>
</html>
