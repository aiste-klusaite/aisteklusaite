<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pradinis</title>
    <link rel="stylesheet" href="header.css">
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Raleway|Source+Sans+Pro&display=swap" rel="stylesheet">
</head>
<body>
<div class="container">
 <!--viskas bus vienam headery-->
    <div class="header-container">
        <div class="title"><h1>MONIKA MOZŪRAITĖ</h1></div>
     <div id="burger" class="burger" onclick="navSlide()"> 
         <div class="line1"></div>
         <div class="line2"></div>
         <div class="line3"></div>
        </div>
        <div class="nav-bar"> <!--linkai į page'us-->
            <ul class="nav-links">
                <li><a class="link" href="../header/pradinis.php" target="_self">Pradžia</a></li> <!--cia bus linkas i pradini psl-->
                <li><a class="link" href="../apie/Apie.php" target="_self">Apie</a></li> 
                <li><a class="link" href="../Nuotraukos/Nuotraukos.php" target="_self">Nuotraukos</a></li>
                <li><a class="link" href="../kontaktai/kontaktai.php" target="_self">Kontaktai</a></li>
            </ul>
        </div>
        <div class="soc-bar">
            <ul class="soc-links">
                <li><a href="https://www.facebook.com/monikaphotography1/"><i class="fab fa-facebook-square"></i></a></li>
                <li><a href="https://www.instagram.com/mozu_reikalai/"><i class="fab fa-instagram"></i></a></li>
                <li><a href="mailto:mozurai1@gmail.com"><i class="fas fa-envelope"></i></a></li>
                <li><a href="tel:+37060062915"><i class="fas fa-mobile-alt"></i></a></li>
            </ul>
        </div> 
    </div>
    <div class="slide-container" onmouseover="showBtn2()" onmouseout="hideBtn2()">
         <i id="prevBtn" class="fas fa-arrow-left"></i>
        <i id="nextBtn" class="fas fa-arrow-right"></i>
        <div class="slide_show" >
        <img src="slides1/slide_foto5.jpg" width="100%"  id="paskutine">
        <img src="slides1/slide_foto3.jpg" width="100%" height="100%" class="img2">  
        <img src="slides1/slide_foto2.jpg" width="100%" height="100%">  
        <img src="slides1/slide_foto1.jpg" width="100%" height="100%"> 
        <img src="slides1/slide_foto5.jpg" width="100%" height="100%">
        <img src="slides1/slide_foto3.jpg" width="100%" height="100%" id="pirma">     
        </div>
    </div>
    <div class="responsive_container" onmouseover="showBtn()" onmouseout="hideBtn()">
        <i id="prevBtn_res"  class="fas fa-arrow-left"></i>
        <i id="nextBtn_res" class="fas fa-arrow-right"></i>
        <div class="responsive_slides">
            <img src="slides2/slide_foto4.jpg" width="100%" height="100%"id="paskutine_">
            <img src="slides2/slide_foto1.jpg" width="100%" height="100%">
            <img src="slides2/slide_foto2.JPG" width="100%" height="100%">
            <img src="slides2/slide_foto3.jpg" width="100%" height="100%">
            <img src="slides2/slide_foto4.jpg" width="100%" height="100%">
            <img src="slides2/slide_foto1.jpg" width="100%"  height="100%" id="pirma_">
        </div>
</div>
    <footer>
    <h4>MONIKA MOZŪRAITĖ</h4>
    <p>COPYRIGHT 2020</p>
    </footer>
</div>
    <script src="header.js"></script>
    </body>
</html>