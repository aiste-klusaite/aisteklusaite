$('[data-fancybox="gallery"]').fancybox({
	protect: true,
    animationEffect: "fade",
    transitionEffect: "fade",
    animationDuration: 1000,
    buttons: [
    "zoom",
    //"share",
    "slideShow",
    //"fullScreen",
    //"download",
    "thumbs",
    "close"
  ]
});