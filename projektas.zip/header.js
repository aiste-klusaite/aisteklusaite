function navSlide(){
    document.getElementById("burger");
    let burger = document.querySelector('.burger');
    let nav = document.querySelector('.nav-links');
    let navLinks = document.querySelectorAll('.nav-links > li');
    
    burger.addEventListener('click',()=>{
        nav.classList.toggle('nav-active'); //nav issokimas
        

        
        navLinks.forEach((link, index) => {
            if(link.style.animation){
                link.style.animation = '';
            }else{
                link.style.animation = `navLinkFade 1s ease forwards ${index / 5 + 0}s`
            }
        });
         //burgeris
        burger.classList.toggle('exit');
    });
}


//PC ekranas

let mySlides = document.querySelector('.slide_show');
let SlideImg = document.querySelectorAll('.slide_show img');

let prevBtn = document.querySelector('#prevBtn');
let nextBtn = document.querySelector('#nextBtn');

let skaicius = 1;
let size = SlideImg[0].clientWidth;

mySlides.style.transform = 'translateX(' + (-size * skaicius) + 'px)';

nextBtn.addEventListener('click', ()=>{
     if(skaicius >= SlideImg.length - 1) return;
    mySlides.style.transition = "transform 0.8s linear";
    skaicius++;
    mySlides.style.transform = 'translateX(' + (-size * skaicius) + 'px)';
});

prevBtn.addEventListener('click', ()=>{
    if(skaicius <= 0) return;
    mySlides.style.transition = "transform 0.8s linear";
    skaicius--;
    mySlides.style.transform = 'translateX(' + (-size * skaicius) + 'px)';
});

mySlides.addEventListener('transitionend', ()=>{
    if(SlideImg[skaicius].id === 'paskutine'){
        mySlides.style.transition = "none";
        skaicius = SlideImg.length - 2;
        mySlides.style.transform = 'translateX(' + (-size * skaicius) + 'px)';
    }
    if(SlideImg[skaicius].id === 'pirma'){
        mySlides.style.transition = "none";
        skaicius = SlideImg.length - skaicius;
        mySlides.style.transform = 'translateX(' + (-size * skaicius) + 'px)';
    }
});

//responsive ekranas
let mySlidesRes = document.querySelector('.responsive_slides');
let SlideImgRes = document.querySelectorAll('.responsive_slides img');

let prevBtnRes = document.querySelector('#prevBtn_res');
let nextBtnRes = document.querySelector('#nextBtn_res');

let num = 1;
let size_r = SlideImgRes[0].clientWidth;

mySlidesRes.style.transform = 'translateX(' + (-size_r * num) + 'px)';

nextBtnRes.addEventListener('click', ()=>{
     if(num >= SlideImgRes.length - 1) return;
    mySlidesRes.style.transition = "transform 1s linear";
    num++;
    mySlidesRes.style.transform = 'translateX(' + (-size_r * num) + 'px)';
});

prevBtnRes.addEventListener('click', ()=>{
    if(skaicius <= 0) return;
    mySlidesRes.style.transition = "transform 0.8s linear";
    num--;
    mySlidesRes.style.transform = 'translateX(' + (-size_r * num) + 'px)';
});

mySlidesRes.addEventListener('transitionend', ()=>{
    if(SlideImgRes[num].id === 'paskutine_'){
        mySlidesRes.style.transition = "none";
        num = SlideImgRes.length - 2;
        mySlidesRes.style.transform = 'translateX(' + (-size_r * num) + 'px)';
    }
    if(SlideImgRes[num].id === 'pirma_'){
        mySlidesRes.style.transition = "none";
        num = SlideImgRes.length - num;
        mySlidesRes.style.transform = 'translateX(' + (-size_r * num) + 'px)';
    }
});

//button responsive

function showBtn(){ 
   let nextButton = document.getElementById('nextBtn_res');
    let prevButton = document.getElementById('prevBtn_res');
       nextButton.style.visibility = 'visible';
       prevButton.style.visibility = 'visible'; }
   
    function hideBtn(){ 
    let nextButton1 = document.getElementById('nextBtn_res');
    let prevButton1 = document.getElementById('prevBtn_res');
       nextButton1.style.visibility = 'hidden';
       prevButton1.style.visibility = 'hidden'; }   

//button pc ekranui

function showBtn2(){
    let nextButton2 = document.getElementById('nextBtn');
    let prevButton2 = document.getElementById('prevBtn');
    nextButton2.style.visibility = 'visible';
    prevButton2.style.visibility = 'visible';
}
function hideBtn2(){
    let nextButton3 = document.getElementById('nextBtn');
    let prevButton3 = document.getElementById('prevBtn');
    nextButton3.style.visibility = 'hidden';
    prevButton3.style.visibility = 'hidden';
}



       
        
        
        
        