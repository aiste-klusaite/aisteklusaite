<?php
require __DIR__ . '/../forms/formContact.php';
?>

<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="style3.css">
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Raleway|Source+Sans+Pro&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container">
         <div class="header-container">
        <div class="title"><h1>MONIKA MOZŪRAITĖ</h1></div>
     <div id="burger" class="burger" onclick="navSlide()"> 
         <div class="line1"></div>
         <div class="line2"></div>
         <div class="line3"></div>
        </div>
        <div class="nav-bar"> <!--linkai į page'us-->
            <ul class="nav-links">
                <li><a class="link" href="../header/pradinis.php" target="_self">Pradžia</a></li> <!--cia bus linkas i pradini psl-->
                <li><a class="link" href="../apie/Apie.php" target="_self">Apie</a></li> 
                <li><a class="link" href="../Nuotraukos/Nuotraukos.php" target="_self">Nuotraukos</a></li>
                <li><a class="link" href="../kontaktai/kontaktai.php" target="_self">Kontaktai</a></li>
            </ul>
        </div>
        <div class="soc-bar">
            <ul class="soc-links">
                <li><a href="https://www.facebook.com/monikaphotography1/"><i class="fab fa-facebook-square"></i></a></li>
                <li><a href="https://www.instagram.com/mozu_reikalai/"><i class="fab fa-instagram"></i></a></li>
                <li><a href="mailto:mozurai1@gmail.com"><i class="fas fa-envelope"></i></a></li>
                <li><a href="tel:+37060062915"><i class="fas fa-mobile-alt"></i></a></li>
            </ul>
        </div> 
    </div>
        <div class="main1">
        <div class="contact">
            <h3>SUSISIEK SU MANIMI</h3>
            <p>El.paštas:<a href="mailto:mozurai1@gmail.com">mozurai1@gmail.com</a></p>
            <p>Tel.numeris:<a href="tel:+37060062915">+37060062915</a></p>
                <div class="icons_foto">
                   <a href="https://www.facebook.com/monikaphotography1/"><i class="fab fa-facebook-square foto-icon"></i></a>
                   <a href="https://www.facebook.com/monikaphotography1/"><i class="fab fa-instagram foto-icon"></i></a>
                </div>
        </div>
        <div class="contact_foto">
      <img class="foto" src="../foto/foto_up3.jpg" alt="xixi" width="100%">
    <img class="foto1" src="../foto/foto_up4.jpg" alt="xixi" width="100%">
     </div >
    </div>
    <div class="main-container">
    <form class="main2" id="contact" action="kontaktai.php" method="post">
            <div class="box1">
            <div class="name1">
                <div class="icon1">
                <i class="fa fa-user icon"></i>
                </div>
                <input class="name" type="text" name="firstName" placeholder="Vardas" required autofocus>
            </div>
            <div class="lastname1">
                <div class="icon2">
                <i class="fa fa-user icon"></i>
                </div>
                <input class="lastname" type="text" name="lastName" placeholder="Pavardė" required>
            </div>
            </div>
            <div class="box2">
            <div class="email1">
                <div class="icon3">
                 <i class="fa fa-envelope icon"></i>  
                </div>
                <input class="email" type="email" name="email" placeholder="El. paštas" required>
            </div>
            <div class="tel1">
                <div class="icon4">
                <i class="fas fa-mobile-alt icon"></i>
                </div>
                <input class="tel" type="tel" name="tel" placeholder="Tel. numeris" required> 
            </div>
            </div>
            <div class="box3">
            <div class="sjb1">
                <div class="icon5">
                <i class="fas fa-feather icon"></i>
                </div>
                <input class="sbj" type="text" name="subject" placeholder="Tema" required> 
            </div>
            </div>
            <div class="box4">
            <div class="msn1">
                <div class="icon6">
                <i class="fas fa-feather icon"></i>
                </div>
                <textarea class="msn" type="text" name="message" placeholder="Žinutė" required></textarea>
                </div>
                </div>
            <div class="btn1">
                <input id="contact-submit" class="btn" type="submit" name="submit" value="Siųsti">
            </div>
    </form>
    <div class="main3">
    <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d36156.34672798902!2d25.57322566983351!3d55.5015039545336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46dd56e4f90bc8bd%3A0x400d18c70e9dbc0!2sUtena!5e0!3m2!1slt!2slt!4v1584968209667!5m2!1slt!2slt" width="100%" height="350" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </div>
        </div>
        </div>
    <footer>
        <h4>MONIKA MOZŪRAITĖ</h4>
        <p>COPYRIGHT 2020</p>
    </footer>

</div>
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY&callback=myMap"></script>
    <script src="../header/header.js"></script>
</body>
</html>