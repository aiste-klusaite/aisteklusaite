
<?php
if(isset($_POST['submit'])){ 
$vardas = $_POST['firstName'];
$pavarde = $_POST['lastName'];
$email = $_POST['email'];
$telefonas = $_POST['tel'];
$tema = $_POST['subject'];
$zinute = $_POST['message'];
         
if(!empty($vardas) && !empty($pavarde) && !empty($email) && !empty($telefonas) && !empty($tema) && !empty($zinute)) {
 if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
$headers = "From:" . "$email";
$to = "aiste.klusaite@gmail.com";
$subject = "$tema";
$message = htmlspecialchars($zinute);
$siuntejas = "$vardas" . "$pavarde" . "$telefonas";
mail($headers, $to, $siuntejas, $subject, $message);
header("Location: kontaktai.php?mailsend");
exit();
        }
    }      
include('duomenuBaze.php');      
} 

?>