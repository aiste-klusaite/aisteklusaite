<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projektas";

$mysqli = new mysqli($servername, $username, $password, $dbname);
if($mysqli->connect_error){
    echo "Atiprašau, bet kažur įsivėlė klaida.\n";
    echo "Klaida:  $mysqli->connect_error \n";
    exit();
}
mysqli_query($mysqli, "INSERT INTO zmones (vardas, pavarde, email, telefonas, tema, zinute)VALUES('$_POST[firstName]', '$_POST[lastName]', '$_POST[email]', '$_POST[tel]', '$_POST[subject]', '$_POST[message]')");



//<?php

//$servername = "localhost";
//$username = "root";
//$password = "";
//$dbname = "form";

//$mysqli = new mysqli($servername, $username, $password, $dbname);
//if($mysqli->connect_error) {
//    echo "Sorry there is a problem.\n";
//    echo 'Error: ' . $mysqli->connect_error . 'n';
//    exit();
//}

//mysqli_query($mysqli, "INSERT INTO user_data (text, subject, email, fullname)
//VALUES('$_POST[text]', '$_POST[subject]', '$_POST[email]', '$_POST[full_name]')");
?>
