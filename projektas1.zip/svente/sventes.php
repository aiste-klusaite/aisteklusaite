<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="sventes.css">
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Raleway|Source+Sans+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
</head>

<body>
    <div class="container">
    <div class="header-container">
        <div class="title"><h1>MONIKA MOZŪRAITĖ</h1></div>
     <div id="burger" class="burger" onclick="navSlide()"> 
         <div class="line1"></div>
         <div class="line2"></div>
         <div class="line3"></div>
        </div>
        <div class="nav-bar"> <!--linkai į page'us-->
            <ul class="nav-links">
                <li><a class="link" href="../header/pradinis.php" target="_self">Pradžia</a></li> <!--cia bus linkas i pradini psl-->
                <li><a class="link" href="../apie/Apie.php" target="_self">Apie</a></li> 
                <li><a class="link" href="../Nuotraukos/Nuotraukos.php" target="_self">Nuotraukos</a></li>
                <li><a class="link" href="../kontaktai/kontaktai.php" target="_self">Kontaktai</a></li>
            </ul>
        </div>
        <div class="soc-bar">
            <ul class="soc-links">
                <li><a href="https://www.facebook.com/monikaphotography1/"><i class="fab fa-facebook-square"></i></a></li>
                <li><a href="https://www.instagram.com/mozu_reikalai/"><i class="fab fa-instagram"></i></a></li>
                <li><a href="mailto:mozurai1@gmail.com"><i class="fas fa-envelope"></i></a></li>
                <li><a href="tel:+37060062915"><i class="fas fa-mobile-alt"></i></a></li>
            </ul>
        </div> 
    </div>
   <div class="foto_row">
       <div><a href="sventes/svente1.jpg" data-fancybox="gallery"><img src="sventes/svente1.jpg" width="100%"></a></div>
       <div><a href="sventes/svente2.jpg" data-fancybox="gallery"><img src="sventes/svente2.jpg" width="100%"></a></div>
       <div><a href="sventes/svente3.jpg" data-fancybox="gallery"><img src="sventes/svente3.jpg" width="100%"></a></div>
       <div><a href="sventes/svente4.jpg" data-fancybox="gallery"><img src="sventes/svente4.jpg" width="100%"></a></div>
       <div><a href="sventes/svente5.jpg" data-fancybox="gallery"><img src="sventes/svente5.jpg" width="100%"></a></div>
        <div><a href="sventes/svente6.jpg" data-fancybox="gallery"><img src="sventes/svente6.jpg" width="100%"></a></div>
       <div><a href="sventes/svente7.jpg" data-fancybox="gallery"><img src="sventes/svente7.jpg" width="100%"></a></div>
       <div><a href="sventes/svente8.jpg" data-fancybox="gallery"><img src="sventes/svente8.jpg" width="100%"></a></div>
        <div><a href="sventes/svente9.jpg" data-fancybox="gallery"><img src="sventes/svente9.jpg" width="100%"></a></div>
        <div><a href="sventes/svente10.jpg" data-fancybox="gallery"><img src="sventes/svente10.jpg" width="100%"></a></div>
        <div><a href="sventes/svente11.jpg" data-fancybox="gallery"><img src="sventes/svente11.jpg" width="100%"></a></div>
        <div><a href="sventes/svente12.jpg" data-fancybox="gallery"><img src="sventes/svente12.jpg" width="100%"></a></div>
       <div><a href="sventes/svente13.jpg" data-fancybox="gallery"><img src="sventes/svente13.jpg" width="100%"></a></div>
       <div><a href="sventes/svente14.jpg" data-fancybox="gallery"><img src="sventes/svente14.jpg" width="100%"></a></div>
        <div><a href="sventes/svente15.jpg" data-fancybox="gallery"><img src="sventes/svente15.jpg" width="100%"></a></div>
        </div>
    <footer>
        <h4>MONIKA MOZŪRAITĖ</h4>
        <p>COPYRIGHT 2020</p>
    </footer>
</div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
    <script src="svente.js"></script><script src="../header/header.js"></script>
</body>
</html>
