<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="style4.css">
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Raleway|Source+Sans+Pro&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container">
      <div class="header-container">
            <div class="title"><h1>MONIKA MOZŪRAITĖ</h1></div>
         <div id="burger" class="burger" onclick="navSlide()"> 
             <div class="line1"></div>
             <div class="line2"></div>
             <div class="line3"></div>
            </div>
            <div class="nav-bar">
                <ul class="nav-links">
                    <li><a class="link" href="../header/pradinis.php" target="_self">Pradžia</a></li> 
                    <li><a class="link" href="../apie/Apie.php" target="_self">Apie</a></li> 
                    <li><a class="link" href="../Nuotraukos/Nuotraukos.php" target="_self">Nuotraukos</a></li>
                    <li><a class="link" href="../kontaktai/kontaktai.php" target="_self">Kontaktai</a></li>
                </ul>
            </div>
            <div class="soc-bar">
                <ul class="soc-links">
                    <li><a href="https://www.facebook.com/monikaphotography1/"><i class="fab fa-facebook-square"></i></a></li>
                    <li><a href="https://www.instagram.com/mozu_reikalai/"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="mailto:mozurai1@gmail.com"><i class="fas fa-envelope"></i></a></li>
                    <li><a href="tel:+37060062915"><i class="fas fa-mobile-alt"></i></a></li>
                </ul>
            </div> 
        </div> 
    <div class="main">
        <div class="main1">
            <div class="sventes">
                <div class="pav1"><a onmouseover="zoomImg()" onmouseout="deZoomImg()" href="../svente/sventes.php" target="_parent">ŠVENČIŲ AKIMIRKOS</a></div>
                <img id="image1" src="../svente/sventes/svente4.jpg" width="100%">
            </div>
        </div>
        <div class="main2">
            <div class="zmones">
                <div class="pav2"><a onmouseover="zoomImg2()" onmouseout="deZoomImg2()" href="../zmones/zmones.php" target="_parent">PORTRETAI</a></div>
                <img id="image2" src="../zmones/portretai/zmones1.jpg" width="100%"></div>
            
            <div class="momentai">
                <div class="pav3"><a onmouseover="zoomImg3()" onmouseout="deZoomImg3()" href="../akimirkos/akimirkos.php" target="_parent">MOMENTAI</a></div>
                <img id="image3" src="../akimirkos/moments/moments1.jpg" width="100%"></div>
        </div>
        <div class="main3">
            <div class="gamta">
                <div class="pav4"><a onmouseover="zoomImg4()" onmouseout="deZoomImg4() "href="../gamtoj/gamta.php" target="_self">GAMTA</a></div><img id="image4" src="../gamtoj/gamta/gamta1.JPG" width="100%"></div>
        </div>
    </div>
    <footer>
        <h4>MONIKA MOZŪRAITĖ</h4>
        <p>COPYRIGHT 2020</p>
    </footer>
</div>
    <script src="nuotraukos.js"></script><script src="../header/header.js"></script>
</body>
</html>