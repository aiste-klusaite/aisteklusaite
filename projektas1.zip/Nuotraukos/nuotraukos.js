//sventes nuoroda
function zoomImg(){
    let zoomIn = document.getElementById("image1");
    zoomIn.style.transition = "transform 3s linear";
    zoomIn.style.transform = 'scale3d(1.2, 1.2, 1.2)';
}

function deZoomImg(){
    let zoomOut = document.getElementById("image1");
    zoomOut.style.transition = "transform 3s linear";
    zoomOut.style.transform = 'scale3d(1, 1, 1)';
}

// zmones nuoroda
function zoomImg2(){
    let zoomIn2 = document.getElementById("image2");
    zoomIn2.style.transition = "transform 3s linear";
    zoomIn2.style.transform = 'scale3d(1.2, 1.2, 1.2)';
}

function deZoomImg2(){
    let zoomOut2 = document.getElementById("image2");
    zoomOut2.style.transition = "transform 3s linear";
    zoomOut2.style.transform = 'scale3d(1, 1, 1)';
}

//momentai nuoroda
function zoomImg3(){
    let zoomIn3 = document.getElementById("image3");
    zoomIn3.style.transition = "transform 3s linear";
    zoomIn3.style.transform = 'scale3d(1.2, 1.2, 1.2)';
}

function deZoomImg3(){
    let zoomOut3 = document.getElementById("image3");
    zoomOut3.style.transition = "transform 3s linear";
    zoomOut3.style.transform = 'scale3d(1, 1, 1)';
}
//gamta nuoroda
function zoomImg4(){
    let zoomIn4 = document.getElementById("image4");
    zoomIn4.style.transition = "transform 3s linear";
    zoomIn4.style.transform = 'scale3d(1.2, 1.2, 1.2)';
}

function deZoomImg4(){
    let zoomOut4 = document.getElementById("image4");
    zoomOut4.style.transition = "transform 3s linear";
    zoomOut4.style.transform = 'scale3d(1, 1, 1)';
}