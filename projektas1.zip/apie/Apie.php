<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="style2.css">
    <script src="https://kit.fontawesome.com/3ad6031a51.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css?family=Raleway|Source+Sans+Pro&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container">
         <div class="header-container">
        <div class="title"><h1>MONIKA MOZŪRAITĖ</h1></div>
     <div id="burger" class="burger" onclick="navSlide()"> 
         <div class="line1"></div>
         <div class="line2"></div>
         <div class="line3"></div>
        </div>
        <div class="nav-bar"> <!--linkai į page'us-->
            <ul class="nav-links">
                <li><a class="link" href="../header/pradinis.php" target="_self">Pradžia</a></li> <!--cia bus linkas i pradini psl-->
                <li><a class="link" href="../apie/Apie.php" target="_self">Apie</a></li> 
                <li><a class="link" href="../Nuotraukos/Nuotraukos.php" target="_self">Nuotraukos</a></li>
                <li><a class="link" href="../kontaktai/kontaktai.php" target="_self">Kontaktai</a></li>
            </ul>
        </div>
        <div class="soc-bar">
            <ul class="soc-links">
                <li><a href="https://www.facebook.com/monikaphotography1/"><i class="fab fa-facebook-square"></i></a></li>
                <li><a href="https://www.instagram.com/mozu_reikalai/"><i class="fab fa-instagram"></i></a></li>
                <li><a href="mailto:mozurai1@gmail.com"><i class="fas fa-envelope"></i></a></li>
                <li><a href="tel:+37060062915"><i class="fas fa-mobile-alt"></i></a></li>
            </ul>
        </div> 
    </div>
        
    <div class="main1">
    
    
    <div class="main2">
        <img class="main_foto" src="../foto/main1_foto.jpg" width="460px" height="370px">
      
    </div>
    <div class="main3">
        <h3>Labas, aš - Monika!</h3>
        <p class="text">Dažnai žmonės prisimena savo pirmuosius kartus. Aš irgi vieną iš tokių prisimenu. Lietingą rudenio vakarą, atostogų metu, mane mama išmokė ryškinti nuotraukas "raudonajame kambarėlyje". Tai buvo mano pirmasis kartas, kai pamilau fotografiją ir pajaučiau jos teikiamus malonumus. Teko prisiliesti prie "Zenit", vėliau pradėjau pyškinti iš eilės visas tėvų juosteles iš senojo "FujiFilm". Galiausiai, sulaukę geresnių laikų, gavau savo pirmąjį skaitmeninį "Olympus" fotoaparatą. Toliau sekė vis naujesni, geresni ir modernesni fotoaparatai, ir už tai esu dėkinga savo tėvams. Fotografija man - aistra. Niekada jai nebuvo nustatyti įkainiai. Visada viską dariau iš malonumo sau. Visi esame skirtingi žmonės, o šiais laikais ir pseudo "fotografų" daugiau nei miške medžių, bet aš save laikau menininke. Žmonės juokias, o aš kaifuoju žiūrėdama pro fotoaparato akutę.</p>
        <a href="../Nuotraukos/Nuotraukos.php" target="_self">GALERIJA</a>
        </div>    
    </div>
    <footer>
    <h4>MONIKA MOZŪRAITĖ</h4>
    <p>COPYRIGHT 2020</p>
    </footer>
    </div>
    <script src="../header/header.js"></script>
</body>
</html>
